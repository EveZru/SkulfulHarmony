package com.example.skulfulharmony.javaobjects.clustering;

public class PuntoCentroide {
    private float genero;
    private float dificultad;

    public PuntoCentroide(float genero, float dificultad) {
        this.genero = genero;
        this.dificultad = dificultad;
    }
}
