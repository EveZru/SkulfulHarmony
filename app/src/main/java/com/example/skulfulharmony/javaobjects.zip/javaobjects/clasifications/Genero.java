package com.example.skulfulharmony.javaobjects.clasifications;

import android.media.Image;

public class Genero {
    private String titulo;
    private Image imagen;

    public Genero(String titulo, Image imagen) {
        this.titulo = titulo;
        this.imagen = imagen;
    }
}
